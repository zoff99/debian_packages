# ToxBlinkenwall

<H3>A nice little Software to transform your Huge LED Wall into a video conferencing system.</H3>
<font size="1">Or you can use any HDMI capable device (TV, Computer Monitor) connected to your PI to receive Video and Audio</font>

### ToxBlinkenwall [@MetalabVie](https://twitter.com/metalabvie)

<img src="https://raw.githubusercontent.com/zoff99/ToxBlinkenwall/master/doc/images/wall_001.png" height="250" />&nbsp;<img src="https://raw.githubusercontent.com/zoff99/ToxBlinkenwall/master/doc/images/wall_002.png" height="250" /><br>
<img src="https://raw.githubusercontent.com/zoff99/ToxBlinkenwall/master/doc/images/wall_003.png" height="250" />
<br><br>


<img src="https://raw.githubusercontent.com/zoff99/ToxBlinkenwall/master/toxblinkenwall_001.png"
      alt="logo"
      height="280" />



