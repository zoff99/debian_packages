#! /bin/bash

_dir=$(dirname "${0}")
_scr=$(basename "$0")

cd "$_dir"/scripts/
. ./"$_scr"
