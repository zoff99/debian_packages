#### by some random twist of fate you stumbled into the Department of Science of Tox-University

some of the subjects we are teaching here are:<br><br>

- [x] Video enchancements
- [x] Audio enchancements
- [x] H264 Codec
- [x] HW accelerated de-/en-coding on Raspberry Pi
- [x] HW accelerated de-/en-coding on Android (with TRIfA)
- [x] HW accelerated de-/en-coding on Linux (with uTox)
- [x] Message V2 (see :https://github.com/TokTok/c-toxcore/issues/735)
- [x] automatic Video bandwith control
- [x] additional threads for A/V
- [x] fix some thread safety issues (see: https://github.com/TokTok/c-toxcore/issues/956)
- [x] make Toxcore API thread safe (see: https://github.com/TokTok/c-toxcore/pull/1382)
- [x] make ToxAV use only public Tox API functions (see: https://github.com/TokTok/c-toxcore/pull/1431)
- [x] resumable Filetransfers, even across restarts (inside c-toxcore)



