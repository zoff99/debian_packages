#! /bin/bash

touchfile=$(dirname "$0")/../_endless_loading_stop.txt
touch "$touchfile"
