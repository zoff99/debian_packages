
Phonebook entries
=

if the root directory of the USB Stick has any of these files,
they will be copied to the ToxBlinkenwall Device (and any files there overwritten!!)

```
book_entry_1.txt
book_entry_2.txt
book_entry_3.txt
book_entry_4.txt
book_entry_5.txt
book_entry_6.txt
book_entry_7.txt
book_entry_8.txt
book_entry_9.txt
```

WLAN
=

if the root directory of the USB Stick has these 2 files

```
wlan_ssid.txt
wlan_pass.txt
```

one containing just the SSID and the other the WPA2 key in plaintext,
ToxBlinkenwall will try to connect to this WLAN access point

