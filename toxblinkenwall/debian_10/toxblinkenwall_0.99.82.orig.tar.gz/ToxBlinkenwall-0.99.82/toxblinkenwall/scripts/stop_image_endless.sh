#! /bin/bash

touchfile=$(dirname "$0")/../_endless_image_stop.txt
touch "$touchfile"
