# Third party dependencies

All toxcore dependencies you want to build yourself should end up here, not in
the source root. This directory is exempt from code style checks.
