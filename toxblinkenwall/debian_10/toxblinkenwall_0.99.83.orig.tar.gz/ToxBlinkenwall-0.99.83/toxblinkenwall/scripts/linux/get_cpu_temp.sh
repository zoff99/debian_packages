#! /bin/bash

sensors |grep 'Physical'
